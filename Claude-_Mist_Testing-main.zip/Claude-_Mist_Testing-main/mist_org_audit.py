"""
mist_org_audit.py
-----------------
CLI entry point for the Mist Org Configuration Audit.

All audit logic lives in mist_audit_core.py — this file is responsible only
for argument parsing, terminal output, and invoking the core engine.

Usage:
    export MIST_API_TOKEN="your_token_here"
    export MIST_ORG_ID="your_org_id_here"   # optional — auto-discovered

    python mist_org_audit.py               # terminal output only
    python mist_org_audit.py --csv         # + export findings.csv
    python mist_org_audit.py --html        # + export findings.html
    python mist_org_audit.py --csv --html  # both exports
    python mist_org_audit.py --fix         # prompt to auto-fix critical issues
    python mist_org_audit.py --dry-run     # show what --fix would do without changing anything
    python mist_org_audit.py --sle-threshold 0.90  # custom SLE pass threshold
    python mist_org_audit.py --cloud-instance EU   # specify cloud region
"""

from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime, timezone

from mist_audit_core import (
    AuditContext,
    MistClient,
    WEAK_PSKS,
    build_csv_bytes,
    build_html_bytes,
    run_audit,
)


# ---------------------------------------------------------------------------
# Terminal printing helpers
# ---------------------------------------------------------------------------

def section(title: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print("=" * 60)


def print_findings(ctx: AuditContext) -> None:
    """Replay findings to the terminal with coloured icons."""
    current_sec = None
    for f in ctx.findings:
        if f["section"] != current_sec:
            section(f["section"])
            current_sec = f["section"]
        icon = {"CRITICAL": "🔴", "WARNING": "⚠️ ", "OK": "✅"}.get(f["severity"], "  ")
        print(f"  {icon}  {f['message']}")


# ---------------------------------------------------------------------------
# --fix: interactive remediation
# ---------------------------------------------------------------------------

def offer_remediations(ctx: AuditContext, dry_run: bool = False) -> None:
    if not ctx.remediations:
        print("\n  ℹ️   No auto-fixable issues found.")
        return

    section("Auto-Fix Available")
    print(f"  {len(ctx.remediations)} issue(s) can be fixed automatically:\n")
    for i, r in enumerate(ctx.remediations, 1):
        prefix = "[DRY-RUN] " if dry_run else ""
        print(f"  [{i}] {prefix}{r['description']}")

    if dry_run:
        print("\n  --dry-run: no changes will be made.")
        return

    print("\n  Enter numbers to fix (e.g. 1,3,5), 'all', or press Enter to skip: ",
          end="", flush=True)

    try:
        raw = input().strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\n  Skipped.")
        return

    if not raw:
        print("  Skipped — no changes made.")
        return

    if raw == "all":
        selected = list(range(len(ctx.remediations)))
    else:
        selected = []
        for part in raw.split(","):
            try:
                idx = int(part.strip()) - 1
                if 0 <= idx < len(ctx.remediations):
                    selected.append(idx)
                else:
                    print(f"  ⚠️   '{part.strip()}' out of range, skipped")
            except ValueError:
                print(f"  ⚠️   '{part.strip()}' is not a number, skipped")

    if not selected:
        print("  No valid selections — no changes made.")
        return

    print(f"\n  Applying {len(selected)} fix(es)…")
    errors = []
    for idx in selected:
        r = ctx.remediations[idx]
        try:
            if r["type"] == "psk":
                while True:
                    try:
                        new_psk = input(f"    New PSK for WLAN fix '{r['description']}' (8–63 chars): ").strip()
                    except (EOFError, KeyboardInterrupt):
                        print("\n    Skipped.")
                        break
                    if len(new_psk) < 8:
                        print("    ⚠️   Too short — minimum 8 characters.")
                        continue
                    if len(new_psk) > 63:
                        print("    ⚠️   Too long — maximum 63 characters.")
                        continue
                    if new_psk in WEAK_PSKS:
                        print("    ⚠️   Still on the weak list — choose a stronger one.")
                        continue
                    r["fix_fn"](new_psk)
                    print(f"    ✅  Applied: {r['description']}")
                    break
            else:
                r["fix_fn"]()
                print(f"    ✅  Applied: {r['description']}")
        except Exception as exc:
            print(f"    🔴  Failed [{idx + 1}]: {exc}")
            errors.append((idx + 1, str(exc)))

    if errors:
        print(f"\n  ⚠️   {len(errors)} fix(es) failed — review errors above.")
    else:
        print("\n  ✅  All selected fixes applied successfully.")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Mist Org Configuration Audit",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--csv",  action="store_true", help="Export findings to CSV")
    parser.add_argument("--html", action="store_true", help="Export findings to HTML")
    parser.add_argument("--fix",  action="store_true", help="Prompt to auto-fix critical issues")
    parser.add_argument("--dry-run", action="store_true",
                        help="List fixable issues without applying any changes")
    parser.add_argument("--csv-out",  default="findings.csv",  metavar="FILE")
    parser.add_argument("--html-out", default="findings.html", metavar="FILE")
    parser.add_argument("--cloud-instance", choices=["US", "EU", "APAC", "Global 1", "Global 2"], default="US",
                        help="Mist cloud region (US, EU, APAC, Global 1, or Global 2)")
    args = parser.parse_args()

    base_url = {
        "US": "https://api.mist.com/api/v1",
        "EU": "https://api.eu.mist.com/api/v1",
        "APAC": "https://api.ac.mist.com/api/v1",
        "Global 1": "https://api.gc1.mist.com/api/v1",
        "Global 2": "https://api.gc2.mist.com/api/v1"
    }[args.cloud_instance]

    # ── Token ────────────────────────────────────────────────────────────────
    token = os.environ.get("MIST_API_TOKEN", "")
    if not token:
        try:
            token = input("Enter your Mist API token: ").strip()
        except (EOFError, KeyboardInterrupt):
            sys.exit("\nAborted.")
    if not token:
        sys.exit("No API token provided — exiting.")

    # ── Org ID ───────────────────────────────────────────────────────────────
    client = MistClient(token, base_url=base_url)

    org_id = os.environ.get("MIST_ORG_ID", "").strip()
    if not org_id:
        try:
            org_id, org_name = client.discover_org()
        except Exception as exc:
            sys.exit(f"Failed to discover org: {exc}")
    else:
        org_name = org_id

    run_at = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    print(f"\n🔍  Mist Org Audit  |  {org_name}  ({org_id})")
    print(f"    Run at: {run_at}")

    # ── Run audit ─────────────────────────────────────────────────────────────
    ctx = AuditContext(client, sle_threshold=args.sle_threshold)

    def _progress(fraction: float, label: str) -> None:
        bar_len = 30
        filled = int(bar_len * fraction)
        bar = "█" * filled + "░" * (bar_len - filled)
        pct = int(fraction * 100)
        print(f"\r  [{bar}] {pct:3d}%  {label:<30}", end="", flush=True)

    try:
        run_audit(ctx, org_id, progress_callback=_progress)
    except Exception as exc:
        print()
        sys.exit(f"\n🔴  Audit failed: {exc}")

    print()  # newline after progress bar

    # ── Print findings ────────────────────────────────────────────────────────
    print_findings(ctx)

    # ── Summary ───────────────────────────────────────────────────────────────
    section("Audit Complete")
    counts = ctx.counts()
    print(f"  🔴  Critical : {counts['CRITICAL']}")
    print(f"  ⚠️   Warnings : {counts['WARNING']}")
    print(f"  ✅  OK       : {counts['OK']}")
    print()

    # ── Exports ───────────────────────────────────────────────────────────────
    if args.csv:
        data = build_csv_bytes(ctx.findings)
        with open(args.csv_out, "wb") as fh:
            fh.write(data)
        print(f"  📄  CSV exported → {args.csv_out}  ({len(ctx.findings)} rows)")

    if args.html:
        data = build_html_bytes(ctx.findings, org_name, run_at)
        with open(args.html_out, "wb") as fh:
            fh.write(data)
        print(f"  🌐  HTML exported → {args.html_out}")

    # ── Remediation ───────────────────────────────────────────────────────────
    if args.fix or args.dry_run:
        offer_remediations(ctx, dry_run=args.dry_run)
    elif ctx.remediations:
        print(f"\n  💡  {len(ctx.remediations)} issue(s) can be auto-fixed.")
        print("      Re-run with --fix to review and apply corrections.\n")


if __name__ == "__main__":
    main()
