"""
mist_audit_core.py
------------------
Shared audit engine used by both the CLI (mist_org_audit.py) and the
Streamlit web app (mist_streamlit_audit_app.py).

All API I/O, audit checks, remediation helpers, and export utilities live
here.  Neither the CLI nor the web app should duplicate audit logic.
"""

from __future__ import annotations

import csv
import io
import re
import time
from datetime import datetime, timezone
from typing import Any, Callable

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
API_BASE = "https://api.mist.com/api/v1"

WEAK_PSKS: set[str] = {"88888888", "password", "12345678", "00000000", "11111111"}
BAD_RATE_TEMPLATES: set[str] = {"compatible", "legacy"}
BAND_LABELS: dict[str, str] = {"24": "2.4 GHz", "5": "5 GHz", "6": "6 GHz"}

# Display rows for the sidebar reference table: (group label, firmware version)
AP_FIRMWARE_TABLE: list[tuple[str, str]] = [
    ("AP66",        "0.15.34436"),
    ("AP47",        "0.15.34436"),
    ("AP36 / AP37", "0.15.34436"),
    ("AP45 / AP34", "0.12.27452"),
    ("AP24 / AP64", "0.14.30052"),
    ("AP43 / AP63", "0.12.27452"),
    ("AP43-FIPS",   "0.10.24626"),
    ("AP12 / AP32 / AP33", "0.12.27452"),
    ("AP41 / AP61", "0.12.27452"),
    ("AP21 / BT11", "0.8.21804"),
]

# Flat model → recommended firmware version used by the audit check.
RECOMMENDED_AP_FIRMWARE: dict[str, str] = {
    "AP66":      "0.15.34436",
    "AP47":      "0.15.34436",
    "AP36":      "0.15.34436",
    "AP37":      "0.15.34436",
    "AP45":      "0.12.27452",
    "AP34":      "0.12.27452",
    "AP24":      "0.14.30052",
    "AP64":      "0.14.30052",
    "AP43":      "0.12.27452",
    "AP63":      "0.12.27452",
    "AP43-FIPS": "0.10.24626",
    "AP12":      "0.12.27452",
    "AP32":      "0.12.27452",
    "AP33":      "0.12.27452",
    "AP41":      "0.12.27452",
    "AP61":      "0.12.27452",
    "AP21":      "0.8.21804",
    "BT11":      "0.8.21804",
}

# Alarm types that should be enabled in every org's alarm template.
# Keys are the Mist API alarm type identifiers; values are the UI display names.
# Severity colours match the Mist dashboard: red=critical, orange=major, blue=info.
RECOMMENDED_ALARMS: dict[str, str] = {
    # ── Critical (red) — Hardware ────────────────────────────────────────────
    "mxedge_fan_unplugged":              "Mist Edge Fan Unplugged",
    "switch_fan_alarm":                  "Switch Fan Alarm",
    "switch_poe_controller_failure":     "Switch PoE Controller Failure",
    "vc_member_deleted":                 "Virtual Chassis Member Deleted",
    "vc_port_down":                      "Virtual Chassis Port Down",
    # ── Informational (blue) — Hardware ─────────────────────────────────────
    "switch_restarted":                  "Switch Restarted",
    "switch_down":                       "Switch Offline",
    # ── Major (orange) — Hardware ────────────────────────────────────────────
    "switch_bad_optics":                 "Switch Bad Optics",
    "switch_high_temperature":           "Switch High Temperature",
    "switch_pem_alarm":                  "Switch PEM Alarm",
    "switch_poe_alarm":                  "Switch PoE Alarm",
    "switch_power_supply_alarm":         "Switch Power Supply Alarm",
    "switch_storage_partition_alarm":    "Switch Storage Partition Alarm",
    # ── Marvis Actions ───────────────────────────────────────────────────────
    "bad_cable":                         "Bad Cable",
    "missing_vlan":                      "Missing VLAN",
    "port_flap":                         "Port Flap",
    "port_stuck":                        "Port Stuck",
    "sw_mtu_mismatch":                   "Switch MTU Mismatch",
    "switch_offline":                    "Switch Offline (Marvis)",
    "gw_bad_cable":                      "Gateway Bad Cable",
    "gw_mtu_mismatch":                   "Gateway MTU Mismatch",
    "gw_negotiation_mismatch":           "Gateway Negotiation Mismatch",
    "gw_non_compliant":                  "Gateway Non-Compliant",
    "ap_bad_cable":                      "AP Bad Cable",
    "ap_loop_by_switch_port_flap":       "AP Loop by Switch Port Flap",
    "ap_offline":                        "AP Offline",
    "ap_offline_isp_site_down":          "AP Offline — ISP/Site Down",
    "arp_failure":                       "ARP Failure",
    "authentication_failure":            "Authentication Failure",
    "dhcp_failure":                      "DHCP Failure",
    "dns_failure":                       "DNS Failure",
    "non_compliant":                     "Non-Compliant",
    "psk_failure":                       "PSK Failure",
    "minis_arp_failure":                 "Minis ARP Failure",
    "minis_dhcp_failure":                "Minis DHCP Failure",
}

# Switch firmware reference — keyed by model family (output of _switch_model_family).
# Empty string means "query Mist API for recommended version".
# Users can override individual families via the Streamlit sidebar.
SWITCH_FIRMWARE_TABLE: list[tuple[str, str]] = [
    ("EX2300",  ""),
    ("EX3400",  ""),
    ("EX4000",  ""),
    ("EX4100",  ""),
    ("EX4300",  ""),
    ("EX4400",  ""),
    ("EX4600",  ""),
    ("EX4650",  ""),
    ("QFX5100", ""),
    ("QFX5110", ""),
    ("QFX5120", ""),
    ("ACX710",  ""),
]

RECOMMENDED_SWITCH_FIRMWARE: dict[str, str] = {fam: ver for fam, ver in SWITCH_FIRMWARE_TABLE}

DEFAULT_SLE_THRESHOLD = 0.95
DEFAULT_PAGE_LIMIT = 100
DEVICE_STATS_LIMIT = 1000   # was hard-coded to 200 — now paginated anyway
REQUEST_TIMEOUT = 30        # seconds per HTTP call


# ---------------------------------------------------------------------------
# HTTP session with retry + backoff
# ---------------------------------------------------------------------------

def _build_session(token: str) -> requests.Session:
    """
    Return a requests.Session pre-configured with:
      - Authorization header
      - Automatic retry on 429 / 5xx with exponential backoff
      - Connection pooling (reuses TCP connections across all API calls)
    """
    session = requests.Session()
    session.headers.update({
        "Authorization": f"Token {token}",
        "Content-Type": "application/json",
    })

    retry_strategy = Retry(
        total=5,
        backoff_factor=1,          # waits 1, 2, 4, 8, 16 s between retries
        status_forcelist={429, 500, 502, 503, 504},
        allowed_methods={"GET", "PUT"},
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


# ---------------------------------------------------------------------------
# MistClient — thin wrapper around the session
# ---------------------------------------------------------------------------

class MistClient:
    """
    Stateless API client.  One instance per audit run, shared by all checks.
    Encapsulates:
      - GET / PUT helpers with timeout
      - Generic paginator
      - Org auto-discovery
    """

    def __init__(self, token: str, base_url: str | None = None):
        self.base_url = base_url or API_BASE
        self._session = _build_session(token)

    def get(self, path: str, params: dict | None = None) -> Any:
        url = f"{self.base_url}{path}"
        resp = self._session.get(url, params=params or {}, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def put(self, path: str, payload: dict) -> Any:
        """Mist uses PUT (not PATCH) for resource updates."""
        url = f"{self.base_url}{path}"
        resp = self._session.put(url, json=payload, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def post(self, path: str, payload: dict) -> Any:
        """Create a new resource. Not retried to avoid duplicate creation."""
        url = f"{self.base_url}{path}"
        resp = self._session.post(url, json=payload, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def paginate(self, path: str, params: dict | None = None) -> list:
        """
        Collect every page from a Mist list endpoint.
        Raises ValueError if the response shape is unexpected so callers
        see the problem rather than silently getting an empty list.
        """
        params = dict(params or {})
        params.setdefault("limit", DEFAULT_PAGE_LIMIT)
        page, items = 1, []
        while True:
            params["page"] = page
            data = self.get(path, params)
            if isinstance(data, list):
                chunk = data
            elif isinstance(data, dict):
                chunk = data.get("results", data.get("items", []))
                if not isinstance(chunk, list):
                    raise ValueError(
                        f"Unexpected paginated response shape from {path}: {type(chunk)}"
                    )
            else:
                raise ValueError(f"Unexpected response type from {path}: {type(data)}")
            items.extend(chunk)
            if len(chunk) < params["limit"]:
                break
            page += 1
        return items

    def discover_org(self) -> tuple[str, str]:
        """
        Return (org_id, org_name) from the token's /self record.
        Raises ValueError if no org-scoped privilege is found.
        """
        data = self.get("/self")
        org_privs = [p for p in data.get("privileges", []) if p.get("scope") == "org"]
        if not org_privs:
            raise ValueError("No org-scoped privileges found for this token.")
        return org_privs[0]["org_id"], org_privs[0].get("name", "")

    def list_orgs(self) -> list[dict]:
        """Return all org-scoped privileges (useful for multi-org support)."""
        data = self.get("/self")
        return [p for p in data.get("privileges", []) if p.get("scope") == "org"]


# ---------------------------------------------------------------------------
# Finding / Remediation data classes
# ---------------------------------------------------------------------------

Finding = dict   # {severity: str, section: str, message: str}
Remediation = dict  # {description: str, fix_fn: Callable, type: str, wlan_id: str|None}


# ---------------------------------------------------------------------------
# AuditContext — collects findings + remediations for one run
# ---------------------------------------------------------------------------

class AuditContext:
    """
    Passed through every audit function so they can record results
    without touching any global state.  This makes the audit functions
    unit-testable with a mock MistClient.
    """

    def __init__(
        self,
        client: MistClient,
        sle_threshold: float = DEFAULT_SLE_THRESHOLD,
        ap_firmware_overrides: dict[str, str] | None = None,
        sw_firmware_overrides: dict[str, str] | None = None,
    ):
        self.client = client
        self.sle_threshold = sle_threshold
        self.findings: list[Finding] = []
        self.remediations: list[Remediation] = []
        self.ap_firmware_table: dict[str, str] = {
            **RECOMMENDED_AP_FIRMWARE,
            **(ap_firmware_overrides or {}),
        }
        # Switch overrides: only non-empty values are kept (empty = use Mist API).
        self.sw_firmware_overrides: dict[str, str] = {
            k: v for k, v in {
                **RECOMMENDED_SWITCH_FIRMWARE,
                **(sw_firmware_overrides or {}),
            }.items() if v
        }

    # ── Finding recorders ────────────────────────────────────────────────────

    def ok(self, section: str, msg: str) -> None:
        self.findings.append({"severity": "OK", "section": section, "message": msg})

    def warn(self, section: str, msg: str) -> None:
        self.findings.append({"severity": "WARNING", "section": section, "message": msg})

    def crit(self, section: str, msg: str) -> None:
        self.findings.append({"severity": "CRITICAL", "section": section, "message": msg})

    def add_remediation(
        self,
        description: str,
        fix_fn: Callable,
        rem_type: str = "put",
        wlan_id: str | None = None,
    ) -> None:
        self.remediations.append({
            "description": description,
            "fix_fn": fix_fn,
            "type": rem_type,
            "wlan_id": wlan_id,
        })

    # ── Summary helpers ──────────────────────────────────────────────────────

    def counts(self) -> dict[str, int]:
        return {
            sev: sum(1 for f in self.findings if f["severity"] == sev)
            for sev in ("CRITICAL", "WARNING", "OK")
        }


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def epoch_to_str(ts: int | None) -> str:
    if not ts:
        return "never"
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


# ---------------------------------------------------------------------------
# Audit checks
# ---------------------------------------------------------------------------

def audit_devices(ctx: AuditContext, org_id: str) -> list[dict]:
    """Check device connectivity across the entire org."""
    sec = "Device Health"
    # Use paginate so large orgs (>200 devices) are fully covered
    devices = ctx.client.paginate(
        f"/orgs/{org_id}/stats/devices", {"type": "all"}
    )

    connected = [d for d in devices if d.get("status") == "connected"]
    disconnected = [d for d in devices if d.get("status") == "disconnected"]

    if not disconnected:
        ctx.ok(sec, f"All {len(devices)} devices connected")
    else:
        ctx.ok(sec, f"{len(connected)}/{len(devices)} devices connected")
        for d in disconnected:
            last = epoch_to_str(d.get("last_seen"))
            ctx.crit(sec,
                f"DISCONNECTED — {d.get('name', 'unnamed')} ({d.get('model', '?')}) "
                f"| site: {d.get('site_id', '?')} | last seen: {last}"
            )
    return devices


def audit_sites(ctx: AuditContext, org_id: str) -> list[dict]:
    """Check per-site device connectivity and flag empty sites."""
    sec = "Site Health"
    sites = ctx.client.paginate(f"/orgs/{org_id}/stats/sites")
    for s in sites:
        total = s.get("num_devices", 0)
        connected = s.get("num_devices_connected", 0)
        clients = s.get("num_clients", 0)
        name = s.get("name", s.get("id"))
        if total == 0:
            ctx.warn(sec, f"Empty site (no devices): {name}")
        elif connected < total:
            ctx.crit(sec,
                f"Site '{name}': {connected}/{total} devices connected, {clients} clients"
            )
        else:
            ctx.ok(sec, f"Site '{name}': {connected}/{total} devices, {clients} clients")
    return sites


def audit_site_settings(ctx: AuditContext, org_id: str) -> None:
    """Check RF template assignment and AP config persistence per site."""
    sec = "Site Settings"
    sites = ctx.client.paginate(f"/orgs/{org_id}/sites")
    if not sites:
        ctx.warn(sec, "No sites found in this org")
        return

    for s in sites:
        site_id = s.get("id")
        site_name = s.get("name", site_id)

        # RF Template assignment
        if not s.get("rftemplate_id"):
            ctx.warn(sec,
                f"Site '{site_name}': no RF template assigned — using Mist defaults. "
                "Assign an RF template to enforce consistent radio settings."
            )
        else:
            ctx.ok(sec, f"Site '{site_name}': RF template assigned ✓")

        # AP Config Persistence
        try:
            setting = ctx.client.get(f"/sites/{site_id}/setting")
            if "data" in setting:
                setting = setting["data"]
            if not setting.get("persist_config_on_device", False):
                ctx.crit(sec,
                    f"Site '{site_name}': AP Config Persistence is DISABLED — "
                    "enable so APs can recover from cloud outages using cached config"
                )
                def _make_persist_fix(sid: str, sname: str) -> Callable:
                    def _fix() -> None:
                        cur = ctx.client.get(f"/sites/{sid}/setting")
                        if "data" in cur:
                            cur = cur["data"]
                        ctx.client.put(f"/sites/{sid}/setting",
                                       {**cur, "persist_config_on_device": True})
                    return _fix
                ctx.add_remediation(
                    f"Enable AP Config Persistence on site '{site_name}'",
                    _make_persist_fix(site_id, site_name),
                )
            else:
                ctx.ok(sec, f"Site '{site_name}': AP Config Persistence enabled ✓")
        except Exception as exc:
            ctx.warn(sec, f"Site '{site_name}': could not fetch site setting — {exc}")


def audit_wlans(ctx: AuditContext, org_id: str) -> None:
    """Check WLAN security: weak PSKs, OWE, WPA3 pairwise, 6 GHz."""
    sec = "WLAN Security"
    wlans = ctx.client.paginate(f"/orgs/{org_id}/wlans")
    has_weak = False

    for w in wlans:
        ssid = w.get("ssid", "?")
        auth = w.get("auth", {})
        auth_type = auth.get("type", "?")
        psk = auth.get("psk", "")
        bands = w.get("bands", [])
        pairwise = auth.get("pairwise", [])
        wlan_id = w.get("id", "")

        if auth_type == "psk" and psk in WEAK_PSKS:
            has_weak = True
            ctx.crit(sec, f"WLAN '{ssid}': weak/default PSK detected — rotate immediately")

            def _make_psk_fix(oid: str, wid: str) -> Callable:
                def _fix(new_psk: str) -> None:
                    cur = ctx.client.get(f"/orgs/{oid}/wlans/{wid}")
                    if "data" in cur:
                        cur = cur["data"]
                    cur.setdefault("auth", {})["psk"] = new_psk
                    ctx.client.put(f"/orgs/{oid}/wlans/{wid}", cur)
                return _fix

            ctx.add_remediation(
                f"Replace weak PSK on WLAN '{ssid}'",
                _make_psk_fix(org_id, wlan_id),
                rem_type="psk",
                wlan_id=wlan_id,
            )

        if auth_type == "open" and auth.get("owe") != "enabled":
            ctx.warn(sec, f"WLAN '{ssid}': open auth with no OWE (opportunistic wireless encryption)")

        if auth_type in ("psk", "eap") and pairwise and "wpa3" not in pairwise:
            ctx.warn(sec, f"WLAN '{ssid}': WPA2-only — consider adding WPA3 to pairwise list")

        if "6" not in bands and "wpa3" in pairwise:
            ctx.warn(sec, f"WLAN '{ssid}': WPA3 enabled but 6 GHz band not configured {bands}")

    if not has_weak:
        ctx.ok(sec, "No weak PSKs detected")


def audit_wlan_templates(ctx: AuditContext, org_id: str) -> None:
    """
    Check per-WLAN best-practice settings:
      - Band steering (should be OFF)
      - Data rate templates (should be 'no-legacy')
      - ARP filter (should be ON)
      - Broadcast/multicast filter (should be ON)
    """
    sec = "WLAN Templates"
    wlans = ctx.client.paginate(f"/orgs/{org_id}/wlans")

    tmpl_names: dict[str, str] = {}
    for w in wlans:
        tid = w.get("template_id", "")
        if tid and tid not in tmpl_names:
            tmpl_names[tid] = w.get("ssid", tid)

    for w in wlans:
        ssid = w.get("ssid", "?")
        wlan_id = w.get("id", "")
        tmpl_id = w.get("template_id", "")
        label = f"WLAN '{ssid}' (template: {tmpl_names.get(tmpl_id, tmpl_id or 'no template')})"

        # ── Band steering ────────────────────────────────────────────────────
        if w.get("band_steer", False):
            ctx.crit(sec, f"{label}: band_steer ENABLED — disable to avoid RRM conflicts")

            def _make_bs_fix(oid: str, wid: str) -> Callable:
                def _fix() -> None:
                    cur = ctx.client.get(f"/orgs/{oid}/wlans/{wid}")
                    if "data" in cur:
                        cur = cur["data"]
                    ctx.client.put(f"/orgs/{oid}/wlans/{wid}", {**cur, "band_steer": False})
                return _fix

            ctx.add_remediation(f"Disable band steering on WLAN '{ssid}'",
                                _make_bs_fix(org_id, wlan_id))
        else:
            ctx.ok(sec, f"{label}: band steering OFF ✓")

        # ── Data rate templates ──────────────────────────────────────────────
        rateset = w.get("rateset", {})
        if not rateset:
            ctx.warn(sec, f"{label}: no rateset defined — Mist default will apply")
        else:
            bad_bands: dict[str, dict] = {}
            for band_key, band_label in BAND_LABELS.items():
                band_cfg = rateset.get(band_key)
                if not band_cfg:
                    continue
                tmpl = band_cfg.get("template", "")
                if tmpl in BAD_RATE_TEMPLATES:
                    ctx.crit(sec,
                        f"{label} [{band_label}]: rateset='{tmpl}' — "
                        "compatible/legacy rates hurt airtime efficiency, use 'no-legacy'"
                    )
                    bad_bands[band_key] = band_cfg
                elif tmpl:
                    ctx.ok(sec, f"{label} [{band_label}]: rateset='{tmpl}' ✓")
                else:
                    ctx.warn(sec, f"{label} [{band_label}]: rateset template not set")

            if bad_bands:
                fixed_rateset = {k: dict(v) for k, v in rateset.items()}
                for bk in bad_bands:
                    fixed_rateset[bk]["template"] = "no-legacy"
                band_names = ", ".join(BAND_LABELS[b] for b in bad_bands)

                def _make_rate_fix(oid: str, wid: str, fr: dict) -> Callable:
                    def _fix() -> None:
                        cur = ctx.client.get(f"/orgs/{oid}/wlans/{wid}")
                        if "data" in cur:
                            cur = cur["data"]
                        ctx.client.put(f"/orgs/{oid}/wlans/{wid}", {**cur, "rateset": fr})
                    return _fix

                ctx.add_remediation(
                    f"Set rateset to 'no-legacy' on WLAN '{ssid}' [{band_names}]",
                    _make_rate_fix(org_id, wlan_id, fixed_rateset),
                )

        # ── ARP filter ───────────────────────────────────────────────────────
        if not w.get("arp_filter", False):
            ctx.crit(sec, f"{label}: arp_filter DISABLED — enable to reduce ARP broadcast overhead")

            def _make_arp_fix(oid: str, wid: str) -> Callable:
                def _fix() -> None:
                    cur = ctx.client.get(f"/orgs/{oid}/wlans/{wid}")
                    if "data" in cur:
                        cur = cur["data"]
                    ctx.client.put(f"/orgs/{oid}/wlans/{wid}", {**cur, "arp_filter": True})
                return _fix

            ctx.add_remediation(f"Enable ARP filter on WLAN '{ssid}'",
                                _make_arp_fix(org_id, wlan_id))
        else:
            ctx.ok(sec, f"{label}: ARP filter enabled ✓")

        # ── Broadcast/multicast filter ────────────────────────────────────────
        if not w.get("limit_bcast", False):
            ctx.crit(sec,
                f"{label}: broadcast/multicast filtering (limit_bcast) DISABLED — "
                "enable to reduce unnecessary airtime consumption"
            )

            def _make_bcast_fix(oid: str, wid: str) -> Callable:
                def _fix() -> None:
                    cur = ctx.client.get(f"/orgs/{oid}/wlans/{wid}")
                    if "data" in cur:
                        cur = cur["data"]
                    ctx.client.put(f"/orgs/{oid}/wlans/{wid}", {**cur, "limit_bcast": True})
                return _fix

            ctx.add_remediation(f"Enable broadcast/multicast filtering on WLAN '{ssid}'",
                                _make_bcast_fix(org_id, wlan_id))
        else:
            ctx.ok(sec, f"{label}: broadcast/multicast filtering enabled ✓")


def audit_rf_templates(ctx: AuditContext, org_id: str, sites: list[dict]) -> None:
    """Audit RF template assignments and per-band settings."""
    sec = "RF Templates"
    templates = ctx.client.paginate(f"/orgs/{org_id}/rftemplates")
    if not templates:
        ctx.warn(sec, "No RF templates found in this org")
        return

    rf_site_map: dict[str, list[str]] = {}
    for s in sites:
        rfid = s.get("rftemplate_id")
        if rfid:
            rf_site_map.setdefault(rfid, []).append(s.get("name", s.get("id")))
    assigned_ids = set(rf_site_map.keys())

    for t in templates:
        tid = t.get("id")
        name = t.get("name", tid)
        if tid not in assigned_ids:
            ctx.warn(sec, f"RF template '{name}' is not assigned to any site")
            continue

        ctx.ok(sec, f"RF template '{name}' assigned to: {', '.join(rf_site_map[tid])}")

        for band_key, band_label in [("band_24", "2.4 GHz"), ("band_5", "5 GHz"), ("band_6", "6 GHz")]:
            band = t.get(band_key, {})
            if not band:
                continue
            if band.get("disabled", False):
                ctx.warn(sec, f"'{name}' → {band_label}: band DISABLED")
                continue

            pwr_min, pwr_max = band.get("power_min"), band.get("power_max")
            if pwr_min is not None and pwr_max is not None:
                if pwr_min == pwr_max:
                    ctx.warn(sec, f"'{name}' → {band_label}: power locked at {pwr_min} dBm (disables RRM)")
                elif pwr_max - pwr_min < 6:
                    ctx.warn(sec, f"'{name}' → {band_label}: narrow power range ({pwr_min}–{pwr_max} dBm)")
                elif pwr_max > 20:
                    ctx.warn(sec, f"'{name}' → {band_label}: power_max={pwr_max} dBm — verify regulatory compliance")
                else:
                    ctx.ok(sec, f"'{name}' → {band_label}: power range {pwr_min}–{pwr_max} dBm ✓")

            bw = band.get("bandwidth")
            if band_label == "6 GHz" and bw and bw < 80:
                ctx.warn(sec, f"'{name}' → {band_label}: bandwidth={bw} MHz — 6 GHz best at 80/160 MHz")

            if band.get("channels"):
                ctx.warn(sec, f"'{name}' → {band_label}: fixed channel list — RRM partially overridden")

            if band.get("allow_rrm_disable", False):
                ctx.warn(sec, f"'{name}' → {band_label}: allow_rrm_disable=true — APs can opt out of RRM")


def audit_network_templates(ctx: AuditContext, org_id: str, sites: list[dict]) -> None:
    """Flag network templates that are not assigned to any site."""
    sec = "Network Templates"
    templates = ctx.client.paginate(f"/orgs/{org_id}/networktemplates")
    assigned_ids = {s.get("networktemplate_id") for s in sites if s.get("networktemplate_id")}
    for t in templates:
        tid = t.get("id")
        name = t.get("name", tid)
        if tid not in assigned_ids:
            ctx.warn(sec, f"Network template '{name}' is not assigned to any site")
        else:
            ctx.ok(sec, f"Network template '{name}' is in use ✓")


def audit_sle(ctx: AuditContext, org_id: str) -> None:
    """Check org-level SLE (Service Level Expectations) scores."""
    sec = "SLE"
    data = ctx.client.get(f"/orgs/{org_id}/stats")
    for sle in data.get("sle", []):
        path = sle.get("path", "?")
        minutes = sle.get("user_minutes", {})
        total = minutes.get("total", 0)
        good = minutes.get("ok", 0)
        if total == 0:
            continue
        ratio = good / total
        pct = f"{ratio:.1%}"
        if ratio < ctx.sle_threshold:
            ctx.crit(sec,
                f"SLE '{path}': {pct} — below {ctx.sle_threshold:.0%} threshold"
            )
        else:
            ctx.ok(sec, f"SLE '{path}': {pct} ✓")


def _parse_fw_version(v: str) -> tuple[int, ...]:
    """Convert '0.14.29411' → (0, 14, 29411) for reliable numeric comparison."""
    return tuple(int(x) for x in re.split(r"[.\-]", v) if x.isdigit())


def _model_key(raw: str, fw_table: dict[str, str] | None = None) -> str:
    """Normalise a Mist model string for lookup in a firmware table.

    Mist sometimes appends a variant suffix (e.g. 'AP43E', 'AP45X').
    Strip a trailing single letter so 'AP43E' → 'AP43', but keep
    'AP43-FIPS' and 'BT11' untouched.
    """
    table = fw_table if fw_table is not None else RECOMMENDED_AP_FIRMWARE
    raw = raw.upper().strip()
    if raw in table:
        return raw
    if len(raw) > 2 and raw[-1].isalpha() and raw[-2].isdigit():
        trimmed = raw[:-1]
        if trimmed in table:
            return trimmed
    return raw


def audit_ap_firmware(ctx: AuditContext, org_id: str) -> None:
    """Check that every AP is running its model-specific recommended firmware."""
    sec = "AP Firmware"
    client = ctx.client

    all_devices = client.paginate(f"/orgs/{org_id}/stats/devices", {"type": "all"})
    aps = [d for d in all_devices if d.get("type") == "ap"]
    if not aps:
        ctx.ok(sec, "No APs found in org")
        return

    outdated: list[dict] = []
    for ap in aps:
        name    = ap.get("name") or ap.get("mac", "?")
        model   = ap.get("model", "")
        current = ap.get("version") or ap.get("firmware", "unknown")

        key = _model_key(model, ctx.ap_firmware_table)
        expected = ctx.ap_firmware_table.get(key)

        if expected is None:
            ctx.warn(sec, f"AP '{name}' ({model}) — model not in firmware reference table")
            continue

        if current == expected:
            ctx.ok(sec, f"AP '{name}' ({model}) — firmware {current} ✓")
        else:
            ctx.warn(
                sec,
                f"AP '{name}' ({model}) — firmware {current} "
                f"(recommended: {expected})",
            )
            outdated.append(ap)

    if outdated:
        outdated_ids = [ap["id"] for ap in outdated if ap.get("id")]

        def _upgrade_aps(_ids: list[str] = outdated_ids) -> str:
            client.post(f"/orgs/{org_id}/devices/upgrade", {
                "device_ids": _ids,
                "version": "latest",
                "reboot": False,
                "enable_p2p": False,
            })
            return f"Queued firmware upgrade to 'latest' for {len(_ids)} AP(s)"

        ctx.add_remediation(
            f"Upgrade firmware on {len(outdated)} AP(s) to model-recommended version",
            _upgrade_aps,
        )


def audit_alarm_template(ctx: AuditContext, org_id: str) -> None:
    """Check that an alarm template is assigned and recommended alarms are enabled."""
    sec = "Alarm Template"
    client = ctx.client

    _alarm_delivery = {"enabled": True, "to_org_admins": True, "to_site_admins": True}

    org_setting = client.get(f"/orgs/{org_id}/setting")
    alarmtemplate_id = org_setting.get("alarmtemplate_id")

    if not alarmtemplate_id:
        ctx.crit(sec, "No alarm template exists")

        def _create_and_assign() -> str:
            rules = {
                key: {"enabled": True, "delivery": _alarm_delivery}
                for key in RECOMMENDED_ALARMS
            }
            new_tmpl = client.post(f"/orgs/{org_id}/alarmtemplates", {
                "name": "Recommended Alarms",
                "delivery": _alarm_delivery,
                "rules": rules,
            })
            tmpl_id = new_tmpl["id"]
            client.put(f"/orgs/{org_id}/setting", {"alarmtemplate_id": tmpl_id})
            return f"Created alarm template '{new_tmpl.get('name')}' (ID: {tmpl_id}) and assigned to org"

        ctx.add_remediation(
            "Create alarm template with all recommended alarms and assign to org",
            _create_and_assign,
        )
        return

    ctx.ok(sec, "Alarm template assigned ✓")

    try:
        tmpl = client.get(f"/orgs/{org_id}/alarmtemplates/{alarmtemplate_id}")
    except requests.HTTPError as exc:
        if exc.response is not None and exc.response.status_code == 404:
            ctx.crit(
                sec,
                "Assigned alarm template no longer exists — "
                "use the Auto-Fix panel to create and assign a new one with all recommended alarms.",
            )

            def _create_and_replace() -> str:
                rules = {
                    key: {"enabled": True, "delivery": _alarm_delivery}
                    for key in RECOMMENDED_ALARMS
                }
                new_tmpl = client.post(f"/orgs/{org_id}/alarmtemplates", {
                    "name": "Recommended Alarms",
                    "delivery": _alarm_delivery,
                    "rules": rules,
                })
                tmpl_id = new_tmpl["id"]
                client.put(f"/orgs/{org_id}/setting", {"alarmtemplate_id": tmpl_id})
                return (
                    f"Created alarm template '{new_tmpl.get('name')}' "
                    f"(ID: {tmpl_id}) and assigned to org"
                )

            ctx.add_remediation(
                "Create new alarm template with recommended alarms and assign to org",
                _create_and_replace,
            )
            return
        raise

    rules = tmpl.get("rules", {})

    disabled_keys: list[str] = []
    for alarm_key, alarm_label in RECOMMENDED_ALARMS.items():
        rule = rules.get(alarm_key, {})
        if not rule.get("enabled", False):
            ctx.warn(sec, f"Recommended alarm not enabled: {alarm_label} ({alarm_key})")
            disabled_keys.append(alarm_key)
        else:
            ctx.ok(sec, f"Alarm enabled: {alarm_label} ✓")

    if disabled_keys:
        def _enable_missing(
            _tmpl_id: str = alarmtemplate_id,
            _keys: list[str] = disabled_keys,
        ) -> str:
            current = client.get(f"/orgs/{org_id}/alarmtemplates/{_tmpl_id}")
            current_rules = current.get("rules", {})
            for key in _keys:
                current_rules.setdefault(key, {})
                current_rules[key]["enabled"] = True
                current_rules[key].setdefault("delivery", _alarm_delivery)
            current["rules"] = current_rules
            client.put(f"/orgs/{org_id}/alarmtemplates/{_tmpl_id}", current)
            labels = [RECOMMENDED_ALARMS[k] for k in _keys]
            return f"Enabled {len(_keys)} alarm(s) in template: {', '.join(labels)}"

        ctx.add_remediation(
            f"Enable {len(disabled_keys)} missing recommended alarm(s) in existing template",
            _enable_missing,
        )


def audit_marvis_actions(ctx: AuditContext, org_id: str) -> None:
    """Surface open Marvis AI action items as audit findings."""
    sec = "Marvis Actions"
    client = ctx.client

    # Mist requires a time window; request the last 24 hours.
    end_ts = int(time.time())
    start_ts = end_ts - 86400

    try:
        data = client.get(
            f"/orgs/{org_id}/insights/marvis",
            params={"start": start_ts, "end": end_ts},
        )
    except requests.HTTPError as exc:
        if exc.response is not None and exc.response.status_code in (404, 402):
            return  # Marvis not available for this org tier — skip silently
        raise

    actions = data if isinstance(data, list) else data.get("results", data.get("items", []))

    if not actions:
        ctx.ok(sec, "No open Marvis action items ✓")
        return

    for action in actions:
        category = action.get("category", "?")
        name     = action.get("name", action.get("type", action.get("action", "?")))
        severity = str(action.get("severity", "info")).upper()
        impact   = action.get("impact", {})

        parts = []
        if impact.get("num_aps"):
            parts.append(f"{impact['num_aps']} AP(s)")
        if impact.get("num_clients"):
            parts.append(f"{impact['num_clients']} client(s)")
        if impact.get("num_sites"):
            parts.append(f"{impact['num_sites']} site(s)")
        impact_str = f" — affecting {', '.join(parts)}" if parts else ""

        msg = f"[{category}] {name}{impact_str}"
        if severity in ("CRITICAL", "HIGH", "ERROR"):
            ctx.crit(sec, msg)
        else:
            ctx.warn(sec, msg)


def audit_wlan_roaming(ctx: AuditContext, org_id: str) -> None:
    """Check that WLANs have 802.11r (Fast BSS Transition) enabled."""
    sec = "WLAN Roaming"
    client = ctx.client
    wlans = client.paginate(f"/orgs/{org_id}/wlans")

    if not wlans:
        ctx.ok(sec, "No WLANs found")
        return

    for w in wlans:
        ssid = w.get("ssid", "?")

        # Mist exposes 802.11r as enable_11r boolean or roam_mode containing "11r".
        roam_mode = str(w.get("roam_mode", "")).lower()
        has_11r   = w.get("enable_11r", False) or "11r" in roam_mode

        if not has_11r:
            ctx.warn(sec, f"WLAN '{ssid}': 802.11r (Fast BSS Transition) not enabled")

            def _make_11r_fix(oid: str, wid: str) -> Callable:
                def _fix() -> None:
                    cur = client.get(f"/orgs/{oid}/wlans/{wid}")
                    if "data" in cur:
                        cur = cur["data"]
                    cur["enable_11r"] = True
                    client.put(f"/orgs/{oid}/wlans/{wid}", cur)
                return _fix

            ctx.add_remediation(
                f"Enable 802.11r on WLAN '{ssid}'",
                _make_11r_fix(org_id, w.get("id", "")),
            )
        else:
            ctx.ok(sec, f"WLAN '{ssid}': 802.11r enabled ✓")


def _switch_model_family(model: str) -> str:
    """'EX2300-24P' → 'EX2300', 'QFX5100-48S' → 'QFX5100'."""
    m = re.match(r'^([A-Za-z]+\d+)', model.strip())
    return m.group(1).upper() if m else model.upper()


def _fetch_recommended_switch_version(client: "MistClient", model: str) -> str | None:
    """Ask Mist for the latest stable firmware version available for a switch model."""
    try:
        versions = client.get("/const/device_versions", params={"model": model, "type": "switch"})
        if not isinstance(versions, list) or not versions:
            return None
        # Each entry has at least a 'version' field; skip beta/rc entries.
        stable = [
            v["version"] for v in versions
            if isinstance(v, dict)
            and v.get("version")
            and not v.get("beta", False)
            and "rc" not in str(v.get("version", "")).lower()
            and "beta" not in str(v.get("version", "")).lower()
        ]
        pool = stable or [v["version"] for v in versions if isinstance(v, dict) and v.get("version")]
        return max(pool, key=_parse_fw_version) if pool else None
    except Exception:
        return None


def audit_switch_firmware(ctx: AuditContext, org_id: str) -> None:
    """Check every switch in the org inventory against the recommended firmware version."""
    sec = "Switch Firmware"
    client = ctx.client

    # Use inventory to get ALL switches (including offline/disconnected).
    inventory = client.paginate(f"/orgs/{org_id}/inventory", {"type": "switch"})
    if not inventory:
        ctx.ok(sec, "No switches found in org inventory")
        return

    # Build a firmware-version lookup from stats (connected devices only).
    # Keyed by device id, falls back by mac.
    stats_by_id:  dict[str, dict] = {}
    stats_by_mac: dict[str, dict] = {}
    try:
        stats_list = client.paginate(f"/orgs/{org_id}/stats/devices", {"type": "switch"})
        for d in stats_list:
            if d.get("id"):
                stats_by_id[d["id"]] = d
            if d.get("mac"):
                stats_by_mac[d["mac"].lower()] = d
    except Exception:
        pass  # Stats unavailable — firmware will show as unknown for all switches.

    # Cache recommended version per model (one Mist API call per unique model).
    _rec_cache: dict[str, str | None] = {}

    def _recommended_for(model: str) -> tuple[str | None, str]:
        fam = _switch_model_family(model)
        # 1. User override
        if fam in ctx.sw_firmware_overrides:
            return ctx.sw_firmware_overrides[fam], "configured"
        # 2. Mist API
        if fam not in _rec_cache:
            _rec_cache[fam] = _fetch_recommended_switch_version(client, model)
        if _rec_cache[fam]:
            return _rec_cache[fam], "Mist"
        return None, ""

    outdated: list[dict] = []
    for sw in inventory:
        sw_id  = sw.get("id", "")
        mac    = str(sw.get("mac", "")).lower()
        name   = sw.get("name") or sw.get("hostname") or mac or "?"
        model  = sw.get("model", "")

        # Firmware version: prefer stats record, fall back to inventory field.
        stats  = stats_by_id.get(sw_id) or stats_by_mac.get(mac, {})
        current = (
            stats.get("version")
            or stats.get("firmware")
            or sw.get("version")
            or sw.get("firmware")
            or "unknown"
        )

        expected, source = _recommended_for(model)

        if not expected:
            ctx.warn(sec, f"Switch '{name}' ({model}) — no recommended firmware found")
            continue

        if current == "unknown":
            ctx.warn(
                sec,
                f"Switch '{name}' ({model}) — firmware version unknown "
                f"(device may be offline; recommended: {expected})",
            )
            outdated.append({**sw, **stats})
            continue

        try:
            up_to_date = _parse_fw_version(current) >= _parse_fw_version(expected)
        except Exception:
            up_to_date = current == expected

        if up_to_date:
            ctx.ok(sec, f"Switch '{name}' ({model}) — firmware {current} ✓")
        else:
            ctx.warn(
                sec,
                f"Switch '{name}' ({model}) — firmware {current} "
                f"(recommended: {expected} [{source}])",
            )
            outdated.append({**sw, **stats})

    if outdated:
        outdated_ids = [d["id"] for d in outdated if d.get("id")]

        def _upgrade_switches(_ids: list[str] = outdated_ids) -> str:
            client.post(f"/orgs/{org_id}/devices/upgrade", {
                "device_ids": _ids,
                "version": "latest",
                "reboot": False,
                "enable_p2p": False,
            })
            return f"Queued firmware upgrade to 'latest' for {len(_ids)} switch(es)"

        ctx.add_remediation(
            f"Upgrade firmware on {len(outdated)} switch(es) to recommended version",
            _upgrade_switches,
        )


# ---------------------------------------------------------------------------
# Full audit runner
# ---------------------------------------------------------------------------

AUDIT_STEPS = [
    ("Device Health",     lambda ctx, oid, sites: audit_devices(ctx, oid)),
    ("AP Firmware",       lambda ctx, oid, sites: audit_ap_firmware(ctx, oid)),
    ("Switch Firmware",   lambda ctx, oid, sites: audit_switch_firmware(ctx, oid)),
    ("Site Health",       lambda ctx, oid, sites: audit_sites(ctx, oid)),
    ("Site Settings",     lambda ctx, oid, sites: audit_site_settings(ctx, oid)),
    ("WLAN Security",     lambda ctx, oid, sites: audit_wlans(ctx, oid)),
    ("WLAN Roaming",      lambda ctx, oid, sites: audit_wlan_roaming(ctx, oid)),
    ("WLAN Templates",    lambda ctx, oid, sites: audit_wlan_templates(ctx, oid)),
    ("RF Templates",      lambda ctx, oid, sites: audit_rf_templates(ctx, oid, sites)),
    ("Network Templates", lambda ctx, oid, sites: audit_network_templates(ctx, oid, sites)),
    ("Alarm Template",    lambda ctx, oid, sites: audit_alarm_template(ctx, oid)),
    ("Marvis Actions",    lambda ctx, oid, sites: audit_marvis_actions(ctx, oid)),
    ("SLE",               lambda ctx, oid, sites: audit_sle(ctx, oid)),
]


def run_audit(
    ctx: AuditContext,
    org_id: str,
    progress_callback: Callable[[float, str], None] | None = None,
) -> None:
    """
    Run every audit step.  progress_callback(fraction, label) is called
    before each step so callers can drive a progress bar.
    """
    # Fetch sites once; several checks need it
    sites = ctx.client.paginate(f"/orgs/{org_id}/stats/sites")

    n = len(AUDIT_STEPS)
    for i, (label, fn) in enumerate(AUDIT_STEPS):
        if progress_callback:
            progress_callback(i / n, label)
        fn(ctx, org_id, sites)

    if progress_callback:
        progress_callback(1.0, "Audit complete!")


# ---------------------------------------------------------------------------
# Export helpers
# ---------------------------------------------------------------------------

def build_csv_bytes(findings: list[Finding]) -> bytes:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=["severity", "section", "message"])
    writer.writeheader()
    writer.writerows(findings)
    return buf.getvalue().encode("utf-8")


_SEV_STYLE = {
    "CRITICAL": ("🔴", "#fde8e8", "#c0392b"),
    "WARNING":  ("⚠️",  "#fff8e1", "#e67e22"),
    "OK":       ("✅", "#e8f8e8", "#27ae60"),
}

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Mist Org Audit — {org_name}</title>
<style>
  body  {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
           margin: 2rem; color: #222; background: #f9f9f9; }}
  h1    {{ color: #1a1a2e; }}
  .summary {{ display: flex; gap: 1rem; margin: 1rem 0 2rem; }}
  .badge   {{ padding: .5rem 1.2rem; border-radius: 8px; font-weight: bold; font-size: 1rem; }}
  .crit    {{ background: #fde8e8; color: #c0392b; }}
  .warn    {{ background: #fff8e1; color: #e67e22; }}
  .ok      {{ background: #e8f8e8; color: #27ae60; }}
  table    {{ width: 100%; border-collapse: collapse; background: #fff;
              box-shadow: 0 1px 4px rgba(0,0,0,.1); border-radius: 8px; overflow: hidden; }}
  th    {{ background: #1a1a2e; color: #fff; padding: .7rem 1rem; text-align: left; }}
  td    {{ padding: .6rem 1rem; border-bottom: 1px solid #eee; vertical-align: top; }}
  tr:last-child td {{ border-bottom: none; }}
</style>
</head>
<body>
<h1>🔍 Mist Org Audit</h1>
<p><strong>Org:</strong> {org_name} &nbsp;|&nbsp; <strong>Run at:</strong> {run_at}</p>
<div class="summary">
  <div class="badge crit">🔴 {n_crit} Critical</div>
  <div class="badge warn">⚠️ {n_warn} Warnings</div>
  <div class="badge ok">✅ {n_ok} OK</div>
</div>
<table>
  <thead><tr><th>Severity</th><th>Section</th><th>Finding</th></tr></thead>
  <tbody>
{rows}  </tbody>
</table>
</body>
</html>"""


def build_html_bytes(
    findings: list[Finding],
    org_name: str,
    run_at: str,
) -> bytes:
    sections: dict[str, list] = {}
    for f in findings:
        sections.setdefault(f["section"], []).append(f)

    counts = {s: sum(1 for f in findings if f["severity"] == s)
              for s in ("CRITICAL", "WARNING", "OK")}

    rows = ""
    for items in sections.values():
        for item in items:
            icon, bg, color = _SEV_STYLE.get(item["severity"], ("", "#fff", "#000"))
            rows += (
                f'<tr style="background:{bg}">'
                f'<td style="color:{color};font-weight:bold">{icon} {item["severity"]}</td>'
                f'<td>{item["section"]}</td>'
                f'<td>{item["message"]}</td>'
                f'</tr>\n'
            )

    html = _HTML_TEMPLATE.format(
        org_name=org_name,
        run_at=run_at,
        n_crit=counts["CRITICAL"],
        n_warn=counts["WARNING"],
        n_ok=counts["OK"],
        rows=rows,
    )
    return html.encode("utf-8")
