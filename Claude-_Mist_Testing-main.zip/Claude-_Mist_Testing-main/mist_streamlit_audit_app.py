"""
mist_streamlit_audit_app.py
---------------------------
Streamlit web-app front-end for the Mist Org Configuration Audit.

All audit logic lives in mist_audit_core.py.  This file is responsible
only for the Streamlit UI: sidebar inputs, progress display, results
tables, the remediation panel, and export downloads.

Run:
    streamlit run mist_streamlit_audit_app.py
"""

from __future__ import annotations

from datetime import datetime, timezone

import streamlit as st

from mist_audit_core import (
    AP_FIRMWARE_TABLE,
    RECOMMENDED_AP_FIRMWARE,
    SWITCH_FIRMWARE_TABLE,
    RECOMMENDED_SWITCH_FIRMWARE,
    AuditContext,
    MistClient,
    WEAK_PSKS,
    build_csv_bytes,
    build_html_bytes,
    run_audit,
)

# ---------------------------------------------------------------------------
# Page config (must be first Streamlit call)
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Mist Org Audit",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Custom CSS
# ---------------------------------------------------------------------------
st.markdown("""
<style>
  /* Hide Streamlit chrome */
  footer {visibility: hidden;}
  [data-testid="collapsedControl"] {display: none;}
  button[kind="header"] {display: none;}

  /* Tighter page top padding */
  .block-container {padding-top: 1.5rem;}

  /* Branded header banner */
  .audit-header {
      background: linear-gradient(135deg, #003087 0%, #009bde 100%);
      border-radius: 10px;
      padding: 20px 28px;
      margin-bottom: 1.2rem;
      color: white;
  }
  .audit-header h1 {color: white; margin: 0; font-size: 1.8rem;}
  .audit-header p  {color: rgba(255,255,255,0.85); margin: 4px 0 0; font-size: 0.95rem;}

  /* Summary metric cards */
  .metric-card {
      border-radius: 10px;
      padding: 18px 20px;
      text-align: center;
      font-weight: 600;
  }
  .metric-critical {background:#fde8e8; border-top: 4px solid #c0392b; color:#c0392b;}
  .metric-warning  {background:#fff8e1; border-top: 4px solid #e67e22; color:#e67e22;}
  .metric-ok       {background:#e8f8e8; border-top: 4px solid #27ae60; color:#27ae60;}
  .metric-number   {font-size: 2.2rem; line-height: 1.1;}
  .metric-label    {font-size: 0.85rem; opacity: 0.85; margin-top: 4px;}

  /* Finding rows */
  .finding-row {
      padding: 7px 14px;
      margin: 3px 0;
      border-radius: 6px;
      border-left: 4px solid;
      font-size: 0.9rem;
      line-height: 1.4;
  }
  .finding-critical {border-left-color:#c0392b; background:#fef9f9; color:#1a1a1a !important;}
  .finding-warning  {border-left-color:#e67e22; background:#fffdf5; color:#1a1a1a !important;}
  .finding-ok       {border-left-color:#27ae60; background:#f5fef5; color:#1a1a1a !important;}

  /* Severity pill badges */
  .pill {
      display: inline-block;
      padding: 1px 8px;
      border-radius: 999px;
      font-size: 0.75rem;
      font-weight: 700;
      margin-right: 6px;
      vertical-align: middle;
  }
  .pill-critical {background:#c0392b; color:white;}
  .pill-warning  {background:#e67e22; color:white;}
  .pill-ok       {background:#27ae60; color:white;}

  /* Remediation checkboxes */
  .rem-item {
      padding: 8px 12px;
      border-radius: 6px;
      background: #f0f4f8;
      color: #1a1a1a !important;
      margin-bottom: 6px;
      border-left: 3px solid #009bde;
  }
  .rem-item strong, .rem-item * {
      color: #1a1a1a !important;
  }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SECTION_ICONS: dict[str, str] = {
    "Device Health":     "💻",
    "AP Firmware":       "📡",
    "Switch Firmware":   "🔌",
    "Site Health":       "🏢",
    "Site Settings":     "⚙️",
    "WLAN Security":     "🔒",
    "WLAN Roaming":      "📶",
    "WLAN Templates":    "📋",
    "RF Templates":      "📻",
    "Network Templates": "🌐",
    "Alarm Template":    "🔔",
    "Marvis Actions":    "🤖",
    "SLE":               "📊",
}

BASE_URLS: dict[str, str] = {
    "Global 01": "https://api.mist.com/api/v1",
    "Global 02": "https://api.gc1.mist.com/api/v1",
    "Global 03": "https://api.ac2.mist.com/api/v1",
    "Global 04": "https://api.gc2.mist.com/api/v1",
    "Global 05": "https://api.gc4.mist.com/api/v1",
    "EMEA 01":   "https://api.eu.mist.com/api/v1",
    "EMEA 02":   "https://api.gc3.mist.com/api/v1",
    "EMEA 03":   "https://api.ac6.mist.com/api/v1",
    "EMEA 04":   "https://api.gc6.mist.com/api/v1",
    "APAC 01":   "https://api.ac5.mist.com/api/v1",
    "APAC 02":   "https://api.gc5.mist.com/api/v1",
    "APAC 03":   "https://api.gc7.mist.com/api/v1",
}

# ---------------------------------------------------------------------------
# Session state initialisation
# ---------------------------------------------------------------------------
_DEFAULTS: dict = {
    "findings":          [],
    "remediations":      [],
    "audit_done":        False,
    "org_name":          "",
    "org_id_resolved":   "",
    "run_at":            "",
    "psk_values":        {},
    "fix_results":       [],
    "audit_error":       "",
}
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v

# AP firmware overrides — initialised once from the built-in table.
if "ap_fw_overrides" not in st.session_state:
    st.session_state.ap_fw_overrides = dict(RECOMMENDED_AP_FIRMWARE)

# Switch firmware overrides — empty string means "use Mist API recommendation".
if "sw_fw_overrides" not in st.session_state:
    st.session_state.sw_fw_overrides = dict(RECOMMENDED_SWITCH_FIRMWARE)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _finding_html(sev: str, message: str) -> str:
    icons = {"CRITICAL": "🔴", "WARNING": "⚠️", "OK": "✅"}
    cls   = f"finding-{sev.lower()}"
    pill  = f'<span class="pill pill-{sev.lower()}">{sev}</span>'
    return (
        f'<div class="finding-row {cls}">'
        f'{icons.get(sev, "")} {pill} {message}'
        f'</div>'
    )


def _section_header(sec_name: str, items: list) -> str:
    icon = SECTION_ICONS.get(sec_name, "📋")
    crit = sum(1 for i in items if i["severity"] == "CRITICAL")
    warn = sum(1 for i in items if i["severity"] == "WARNING")
    ok   = sum(1 for i in items if i["severity"] == "OK")
    parts = [f"{icon} {sec_name}"]
    if crit:
        parts.append(f"🔴 {crit}")
    if warn:
        parts.append(f"⚠️ {warn}")
    if ok:
        parts.append(f"✅ {ok}")
    return "   ".join(parts)


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown("### ⚙️ Configuration")

    token = st.text_input(
        "API Token",
        type="password",
        placeholder="Paste your Mist API token",
        key="token",
        help="Generate at Mist → My Profile → API Token",
    )
    cloud_instance = st.selectbox(
        "Cloud Region",
        list(BASE_URLS.keys()),
        help="Select the Mist cloud region for your organization",
    )
    org_id_input = st.text_input(
        "Org ID (optional)",
        placeholder="Auto-discovered from token",
        key="org_id_input",
        help="Leave blank to auto-discover from the token's privileges",
    )
    sle_threshold = st.slider(
        "SLE pass threshold",
        min_value=0.50, max_value=1.00, value=0.95, step=0.01,
        format="%.2f",
        help="SLE scores below this are flagged as CRITICAL",
    )

    with st.expander("📡 Recommended AP Firmware"):
        st.caption("Edit recommended firmware version per AP model. Changes apply on next audit run.")
        if st.button("↺ Reset to defaults", key="ap_fw_reset", use_container_width=True):
            st.session_state.ap_fw_overrides = dict(RECOMMENDED_AP_FIRMWARE)
            st.rerun()
        for model_label, _default_ver in AP_FIRMWARE_TABLE:
            # model_label may be "AP36 / AP37" — iterate each individual model key.
            model_keys = [m.strip() for m in model_label.split("/")]
            # Show one input row per group, keyed to the first model in the group.
            primary_key = model_keys[0]
            current_val = st.session_state.ap_fw_overrides.get(primary_key, _default_ver)
            new_val = st.text_input(
                model_label,
                value=current_val,
                key=f"ap_fw_{primary_key}",
                label_visibility="visible",
            )
            new_val = new_val.strip()
            if new_val and new_val != current_val:
                for mk in model_keys:
                    st.session_state.ap_fw_overrides[mk] = new_val

    with st.expander("🔌 Recommended Switch Firmware"):
        st.caption("Set recommended firmware per switch model family. Leave blank to use Mist API recommendation.")
        if st.button("↺ Reset to defaults", key="sw_fw_reset", use_container_width=True):
            st.session_state.sw_fw_overrides = dict(RECOMMENDED_SWITCH_FIRMWARE)
            st.rerun()
        for family, _default_ver in SWITCH_FIRMWARE_TABLE:
            current_val = st.session_state.sw_fw_overrides.get(family, _default_ver)
            new_val = st.text_input(
                family,
                value=current_val,
                placeholder="e.g. 23.4R1.10  (blank = auto)",
                key=f"sw_fw_{family}",
            ).strip()
            if new_val != current_val:
                st.session_state.sw_fw_overrides[family] = new_val

    st.divider()
    run_btn = st.button(
        "▶  Run Audit",
        type="primary",
        use_container_width=True,
        disabled=not token,
    )
    if not token:
        st.caption("Enter your API token above to enable the audit.")

    if st.session_state.audit_done:
        st.divider()
        st.markdown("### 📥 Export")
        st.download_button(
            "📄 Download CSV",
            data=build_csv_bytes(st.session_state.findings),
            file_name="mist_audit_findings.csv",
            mime="text/csv",
            use_container_width=True,
        )
        st.download_button(
            "🌐 Download HTML Report",
            data=build_html_bytes(
                st.session_state.findings,
                st.session_state.org_name,
                st.session_state.run_at,
            ),
            file_name="mist_audit_findings.html",
            mime="text/html",
            use_container_width=True,
        )


# ---------------------------------------------------------------------------
# Trigger audit
# ---------------------------------------------------------------------------
if run_btn and token:
    for _k, _v in _DEFAULTS.items():
        st.session_state[_k] = _v

    progress_bar = st.progress(0, "Initialising…")
    try:
        base_url = BASE_URLS[cloud_instance]

        _disc = MistClient(token, base_url=base_url)
        if org_id_input.strip():
            org_id = org_id_input.strip()
            try:
                org_name = _disc.get(f"/orgs/{org_id}").get("name", org_id)
            except Exception:
                org_name = org_id
        else:
            org_id, org_name = _disc.discover_org()

        st.session_state.org_name        = org_name
        st.session_state.org_id_resolved = org_id
        st.session_state.run_at = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

        client = MistClient(token, base_url=base_url)
        ctx    = AuditContext(
            client,
            sle_threshold=sle_threshold,
            ap_firmware_overrides=st.session_state.ap_fw_overrides,
            sw_firmware_overrides=st.session_state.sw_fw_overrides,
        )

        def _progress(fraction: float, label: str) -> None:
            progress_bar.progress(
                fraction,
                f"Running: {label}…" if fraction < 1.0 else label,
            )

        run_audit(ctx, org_id, progress_callback=_progress)

        st.session_state.findings     = ctx.findings
        st.session_state.remediations = ctx.remediations
        st.session_state.audit_done   = True

    except Exception as exc:
        st.session_state.audit_error = str(exc)
    finally:
        progress_bar.empty()

    st.rerun()


# ---------------------------------------------------------------------------
# Error banner
# ---------------------------------------------------------------------------
if st.session_state.audit_error:
    st.error(f"**Audit failed:** {st.session_state.audit_error}")


# ---------------------------------------------------------------------------
# Landing page (no audit yet)
# ---------------------------------------------------------------------------
if not st.session_state.audit_done and not st.session_state.audit_error:
    st.markdown("""
    <div class="audit-header">
      <h1>🔍 Mist Org Configuration Audit</h1>
      <p>Automated best-practice checks for Juniper Mist wireless deployments</p>
    </div>
    """, unsafe_allow_html=True)

    col_a, col_b, col_c = st.columns(3)
    with col_a:
        st.markdown("**🔒 Security**")
        st.caption("WLAN encryption, PSK strength, 802.11r fast roaming")
    with col_b:
        st.markdown("**📡 Infrastructure**")
        st.caption("AP & switch firmware, device connectivity, RF templates")
    with col_c:
        st.markdown("**📊 Performance**")
        st.caption("SLE scores, site health, Marvis AI action items")

    st.info("Enter your **Mist API token** in the sidebar and click **▶ Run Audit** to begin.", icon="ℹ️")
    st.stop()


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------
if st.session_state.audit_done:
    findings     = st.session_state.findings
    remediations = st.session_state.remediations
    org_name     = st.session_state.org_name
    run_at       = st.session_state.run_at

    # Header banner
    st.markdown(f"""
    <div class="audit-header">
      <h1>🔍 Mist Org Configuration Audit</h1>
      <p>Org: <strong>{org_name}</strong> &nbsp;|&nbsp; Run at: {run_at}</p>
    </div>
    """, unsafe_allow_html=True)

    # Summary metric cards
    counts = {s: sum(1 for f in findings if f["severity"] == s)
              for s in ("CRITICAL", "WARNING", "OK")}
    c1, c2, c3 = st.columns(3)
    c1.markdown(f"""
        <div class="metric-card metric-critical">
          <div class="metric-number">{counts["CRITICAL"]}</div>
          <div class="metric-label">🔴 Critical</div>
        </div>""", unsafe_allow_html=True)
    c2.markdown(f"""
        <div class="metric-card metric-warning">
          <div class="metric-number">{counts["WARNING"]}</div>
          <div class="metric-label">⚠️ Warnings</div>
        </div>""", unsafe_allow_html=True)
    c3.markdown(f"""
        <div class="metric-card metric-ok">
          <div class="metric-number">{counts["OK"]}</div>
          <div class="metric-label">✅ Passed</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Severity filter
    col_filt, _ = st.columns([2, 4])
    with col_filt:
        sev_filter = st.multiselect(
            "Show severities",
            ["CRITICAL", "WARNING", "OK"],
            default=["CRITICAL", "WARNING"],
        )

    filtered = [f for f in findings if f["severity"] in sev_filter] if sev_filter else findings

    # Group by section
    sections: dict[str, list] = {}
    for f in filtered:
        sections.setdefault(f["section"], []).append(f)

    if not filtered:
        st.success("No findings match the selected filter.")
    else:
        for sec_name, items in sections.items():
            has_crit = any(i["severity"] == "CRITICAL" for i in items)
            with st.expander(_section_header(sec_name, items), expanded=has_crit):
                html_rows = "".join(_finding_html(i["severity"], i["message"]) for i in items)
                st.markdown(html_rows, unsafe_allow_html=True)

    # ── Remediation panel ──────────────────────────────────────────────────
    if remediations:
        st.divider()
        st.markdown("### 🔧 Auto-Fix Available")
        st.caption(
            f"{len(remediations)} issue(s) can be fixed automatically. "
            "Select the fixes you want to apply, then click **Apply Selected Fixes**."
        )

        selected_indices: list[int] = []
        for i, rem in enumerate(remediations):
            col_cb, col_desc = st.columns([0.04, 0.96])
            checked = col_cb.checkbox("", key=f"fix_cb_{i}", label_visibility="collapsed")

            if rem["type"] == "psk":
                col_desc.markdown(
                    f'<div class="rem-item">🔑 <strong>{rem["description"]}</strong></div>',
                    unsafe_allow_html=True,
                )
                if checked:
                    new_psk = st.text_input(
                        "New PSK (8–63 characters)",
                        key=f"psk_input_{rem['wlan_id']}",
                        type="password",
                        placeholder="Enter a strong password",
                    )
                    st.session_state.psk_values[rem["wlan_id"]] = new_psk
                    if new_psk:
                        selected_indices.append(i)
            else:
                col_desc.markdown(
                    f'<div class="rem-item">🔧 {rem["description"]}</div>',
                    unsafe_allow_html=True,
                )
                if checked:
                    selected_indices.append(i)

        st.divider()
        apply_btn = st.button(
            f"⚡ Apply {len(selected_indices)} Selected Fix(es)",
            type="primary",
            disabled=not selected_indices,
        )

        if apply_btn and selected_indices:
            fix_results: list[tuple[str, str, str]] = []
            with st.spinner("Applying fixes…"):
                for idx in selected_indices:
                    rem = remediations[idx]
                    try:
                        if rem["type"] == "psk":
                            new_psk = st.session_state.psk_values.get(rem["wlan_id"], "")
                            if len(new_psk) < 8:
                                fix_results.append(("ERROR", rem["description"], "PSK too short — minimum 8 characters"))
                                continue
                            if len(new_psk) > 63:
                                fix_results.append(("ERROR", rem["description"], "PSK too long — maximum 63 characters"))
                                continue
                            if new_psk in WEAK_PSKS:
                                fix_results.append(("ERROR", rem["description"], "PSK is still on the weak list — choose a stronger one"))
                                continue
                            rem["fix_fn"](new_psk)
                        else:
                            result_msg = rem["fix_fn"]()
                            fix_results.append(("OK", rem["description"], result_msg or "Applied successfully"))
                            continue
                        fix_results.append(("OK", rem["description"], "Applied successfully"))
                    except Exception as exc:
                        fix_results.append(("ERROR", rem["description"], str(exc)))

            st.session_state.fix_results = fix_results
            st.rerun()

    # ── Fix results ────────────────────────────────────────────────────────
    if st.session_state.fix_results:
        st.divider()
        st.markdown("### ✅ Fix Results")
        for status, desc, msg in st.session_state.fix_results:
            if status == "OK":
                st.success(f"**{desc}** — {msg}")
            else:
                st.error(f"**{desc}** — {msg}")
